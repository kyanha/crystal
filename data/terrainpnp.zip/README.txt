Demo level from PnP Terrain Creator.

Permission for use kindly granted by Ralf Westphal.

http://www.pnp-terraincreator.com/
